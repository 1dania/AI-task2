# Face Recognition using OpenCV

This project uses OpenCV and the `face_recognition` library to recognize faces from a webcam in real time.

## 🧰 Requirements

- Python 3.x
- `opencv-python`
- `face_recognition`
- A webcam

## 🛠️ Installation

```bash
pip install opencv-python face_recognition
```

## 📁 Folder Structure

```
face-recognition-opencv/
│
├── images/                # Place known person's images here (e.g. dania.jpg)
├── face_recognition.py    # The main Python script
└── README.md              # Project explanation
```

## ▶️ Run

```bash
python face_recognition.py
```

Press `Q` to quit the app.

## 👩‍💻 How it works

- Loads images from the `images/` folder
- Encodes faces using `face_recognition`
- Captures frames from your webcam
- Compares detected faces to known ones
- Displays name or "Unknown" on the screen

## 📝 Notes

- Name each image in the `images/` folder with the person's name (e.g. `dania.jpg`)